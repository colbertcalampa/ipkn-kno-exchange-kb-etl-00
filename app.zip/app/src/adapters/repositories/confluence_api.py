import requests
import json
from requests.auth import HTTPBasicAuth

from app.src.domain.ports.document_source_port import DocumentSourcePort


class ConfluenceAPIAdapter(DocumentSourcePort):
    def __init__(self, confluence_base_url, credentiales_api):
        self.confluence_base_url = confluence_base_url
        self.credentiales_api = credentiales_api
        self.headers = {"Accept": "application/json"}

    def get_http_auth(self):
        api_token = self.credentiales_api.get('api_token', "")
        user_api_mail = self.credentiales_api.get('user_api_mail', "")
        return HTTPBasicAuth(user_api_mail, api_token)

    def get_page(self, page_id: str) -> dict:
        http_auth = self.get_http_auth()
        headers = self.headers

        url = f"{self.confluence_base_url}/rest/api/content/{page_id}?expand=body.storage,version,space"
        response = requests.get(url, headers=headers, auth=http_auth)
        response.raise_for_status()
        return response.json()
