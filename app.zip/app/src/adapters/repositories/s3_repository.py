import boto3

from app.src.domain.ports.landing_zone_port import LandingZonePort

class S3RepositoryAdapter(LandingZonePort):
    def __init__(self):
        self.s3_client = boto3.client('s3')

    def save(self, page_id: str, page_data: dict[str]) -> dict:
        print(f"Pagina {page_id} cargada en s3 ")
