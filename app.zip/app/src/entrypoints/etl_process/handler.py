import json
import os
from typing import Any, Dict

from app.src.domain.model.document_event import DocumentEvent, DocumentEventType
from app.src.domain.usecases.etl_process_use_case import EtlProcess

from app.src.adapters.repositories.confluence_api import ConfluenceAPIAdapter
from app.src.adapters.repositories.s3_repository import S3RepositoryAdapter
from app.src.adapters.repositories.step_function_trigger import StepFunctionTriggerAdapter
from app.src.adapters.repositories.secrets_manager_adapter import SecretsManagerAdapter

import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

confluence_secret_name = os.getenv("CONFLUENCE_SECRET_NAME", "sm-io-ipkn-kno-exchange-confluence-01")
confluence_base_url = os.getenv("CONFLUENCE_BASE_URL", "https://matrixmvp.atlassian.net/wiki")


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    try:
        logger.info("Iniciando process etl confluence > s3 aws")

        body = json.loads(event.get("body", "{}"))
        page_id = body.get("page_id", None)
        event_type = DocumentEventType(body.get("event_type", None))

        document_event = DocumentEvent(page_id, event_type)

        secret_manager = SecretsManagerAdapter()
        confluence_credential_api = secret_manager.get_secret(confluence_secret_name)

        caso_uso = EtlProcess(
            ConfluenceAPIAdapter(confluence_base_url, confluence_credential_api),
            S3RepositoryAdapter(),
            StepFunctionTriggerAdapter()
        )

        caso_uso.handle_event(document_event)

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'page_id': page_id, 'status': 'OK'})
        }

    except Exception as e:
        logger.error(
            f"Error processing events: {str(e)}",
            extra={
                "event": event,
                "error_type": type(e).__name__
            },
        )
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
