from abc import ABC, abstractmethod


class LandingZonePort(ABC):
    @abstractmethod
    def save(self, page_id: str, page_data: dict[str]) -> dict:
        pass
